

<?php $__env->startSection('content'); ?>

<div class="content-wrapper px-lg-3 px-0">

    <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('registration.studentmanagment', [])->html();
} elseif ($_instance->childHasBeenRendered('Ol5y0Pj')) {
    $componentId = $_instance->getRenderedChildComponentId('Ol5y0Pj');
    $componentTag = $_instance->getRenderedChildComponentTagName('Ol5y0Pj');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('Ol5y0Pj');
} else {
    $response = \Livewire\Livewire::mount('registration.studentmanagment', []);
    $html = $response->html();
    $_instance->logRenderedChild('Ol5y0Pj', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
  
</div>
<!-- / Layout page -->
</div>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('../admin/layout/main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\education-form\Education\resources\views/admin/registration/studentmanagement.blade.php ENDPATH**/ ?>