@extends('../admin/layout/main')

@section('content')

<div class="content-wrapper px-lg-3 px-0">

    <livewire:registration.studentmanagment />
  
</div>
<!-- / Layout page -->
</div>


@endsection